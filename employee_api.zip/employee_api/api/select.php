<?php  
 if(isset($_POST["employee_id"]))  
 {  
      $output = '';  
      $mysqli= new mysqli('localhost', 'root', '', 'employee') or die (mysqli_error($mysqli));
     //  $connect = mysqli_connect("localhost", "root", "", "employee");  
     //  $query = "SELECT * FROM details WHERE Id = '".$_POST["employee_id"]."'";  
     //  $result = mysqli_query($connect, $query);  
      $result=$mysqli->query("SELECT * FROM details WHERE Id='".$_POST["employee_id"]."'") or die($msqli->error());
      $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td width="30%"><label>Name</label></td>  
                     <td width="70%">'.$row["Name"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Address</label></td>  
                     <td width="70%">'.$row["Address"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Department</label></td>  
                     <td width="70%">'.$row["Department"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Email</label></td>  
                     <td width="70%">'.$row["Email"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Total Marks</label></td>  
                     <td width="70%">'.$row["TotalMarks"].' </td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Year</label></td>  
                     <td width="70%">'.$row["Year"].'</td>  
                </tr>  
            
                ';  
      }  
      $output .= "</table></div>";  
      echo $output;  
 }  
 ?>
 