<?php
require 'database.php';

// Get the posted data.
$postdata = file_get_contents("php://input");


if(isset($postdata) && !empty($postdata))
{
  // Extract the data.
  $request = json_decode($postdata);


  // Sanitize.
  $name = mysqli_real_escape_string($mysqli, trim($request->name));
  $department = mysqli_real_escape_string($mysqli, trim($request->department));
  $address = mysqli_real_escape_string($mysqli, trim($request->address));
  $email = mysqli_real_escape_string($mysqli, trim($request->email));
  $totalMarks = mysqli_real_escape_string($mysqli, (int)($request->totalMarks));
  $year = mysqli_real_escape_string($mysqli, (int)($request->year));
 
// $details=$mysqli->query("INSERT INTO details (Id, Name, Department, Address ,Email, TotalMarks, Year)
// VALUES (null, '$name', '$department', '$address', '$email', '$totalMarks', '$year') ") 
//     or die($mysqli->error());
    
//     $details = [
//       'name' => $name,
//       'department' => $department,
//       'address'=> $address,
//       'email' => $email,
//       'totalMarks' => $totalMarks,
//       'year' => $year,
//       'id'    =>  $mysqli->insert_id
//     ];
   
// }
// // if($details){
// //   echo '{"success":"1"}'; 
// // }  else{
// //     echo '{"success":"0"}';
// //   }

// echo json_encode($details);




//   // Create.

 $sql = "INSERT INTO details (Id, Name, Department, Address ,Email, TotalMarks, Year)
VALUES (null, '$name', '$department', '$address', '$email', '$totalMarks', '$year') ";

  if(mysqli_query($mysqli,$sql))
  {
    http_response_code(201);
    
    $details = [
      'name' => $name,
      'department' => $department,
      'address'=> $address,
      'email' => $email,
      'totalMarks' => $totalMarks,
      'year' => $year,
      'id'    =>  $mysqli->insert_id
    ];
    echo json_encode($details);
  }
  else
  {
    http_response_code(422);
  }
}