<?php
/**
 * Returns the list of details.
 */
require 'database.php';

$details = [];

$result=$mysqli->query("SELECT * FROM details") or die($mysqli->error);
$i=0;
while($row = $result->fetch_assoc()){
      $details[$i]['id']    = $row['Id'];
      $details[$i]['name'] = $row['Name'];
      $details[$i]['department'] = $row['Department'];
      $details[$i]['address'] = $row['Address'];
      $details[$i]['email'] = $row['Email'];
      $details[$i]['totalMarks'] = $row['TotalMarks'];
      $details[$i]['year'] = $row['Year'];
      $i++;
    }
echo json_encode($details);
