<?php
require 'database.php';

// Get the posted data.
$postdata = file_get_contents("php://input");

if(isset($postdata) && !empty($postdata))
{
  // Extract the data.
  $request = json_decode($postdata);

  // // Validate.
  // if ((int)$request->id < 1 || trim($request->number) == '' || (float)$request->amount < 0) {
  //   return http_response_code(400);
  // }

  // Sanitize.
  $id    = mysqli_real_escape_string($mysqli, (int)$request->id);
  $name = mysqli_real_escape_string($mysqli, trim($request->name));
  $department = mysqli_real_escape_string($mysqli, trim($request->department));
  $address = mysqli_real_escape_string($mysqli, trim($request->address));
  $email = mysqli_real_escape_string($mysqli, trim($request->email));
  $totalMarks = mysqli_real_escape_string($mysqli, (int)($request->totalMarks));
  $year = mysqli_real_escape_string($mysqli, (int)($request->year));


  //Update.
  $update=$mysqli->query("UPDATE details SET Name = '$name', Department = '$department', Address = '$address', Email = '$email', 
  TotalMarks = '$totalMarks', 
  Year = '$year' WHERE id=$id")
    or die($mysqli->error());

  // if($update)
  // {
  //   http_response_code(204);
   
  //   $details = [
  //     'name' => $name,
  //     'department' => $department,
  //     'address'=> $address,
  //     'email' => $email,
  //     'totalMarks' => $totalMarks,
  //     'year' => $year,
  //     'id'    =>  $id
  //   ];
  //   echo json_encode($details);
  // }
  // else
  // {
  //   return http_response_code(422);
  //   echo json_encode($details);
  // }  


//   $mysqli->query("UPDATE details SET Name = '$name', Department = '$department', Address = '$address', Email = '$email', 
//   TotalMarks = '$totalMarks', 
//   Year = '$year' WHERE id=$id LIMIT 1")
// or die($mysqli->error());

}
echo json_encode($update);