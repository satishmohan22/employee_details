export class Details {
    id:number;
    name:string;
    department:string;
    address:string;
    email:string;
    totalMarks:number;
    year:number;
}
