export class User {
    constructor(
        public fullName:string,
        public phone:number,
        public street:string,
        public city:string

    ){

    }
}
